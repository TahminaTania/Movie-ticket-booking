from os import name
from django.urls import path
from . import views

urlpatterns = [
    path('', views.hello, name='home'),
    path('polls<slug:polls_slug>/sucess', views.confirmReg, name='confirm-reg'),
    path('<slug:polls_slug>', views.details, name='polls_details'),
    # path('<slug:polls_slug>/sucess', views.confirmReg, name='confirm-reg'),
    # path('<slug:polls_slug>', views.details, name='polls_details'),

]
