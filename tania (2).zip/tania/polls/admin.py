from django.contrib import admin

from .models import zara, Location, participant

# Register your models here.


class zaraadmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'locate')
    list_filter = ('title', 'date')
    prepopulated_fields = {'slug': ('title', )}


admin.site.register(zara, zaraadmin)
admin.site.register(Location)
admin.site.register(participant)
