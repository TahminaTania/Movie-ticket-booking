# from turtle import title
import email
from django.db import models
from django.db.models import Model

# Create your models here.


class Location(models.Model):
    name = models.CharField(max_length=200)
    adress = models.CharField(max_length=300)
    postCode = models.CharField(max_length=20)

    def __str__(self):
        return f'{self.name}({self.adress})'


class participant(models.Model):
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.email


class zara(models.Model):
    title = models.CharField(max_length=200)
    organizer_email = models.EmailField()
    date = models.DateField()
    slug = models.SlugField(unique=True)
    details = models.TextField()
    image = models.ImageField(upload_to='images', null=True, blank=True)
    locate = models.ForeignKey(Location, on_delete=models.CASCADE,
                               null=True, blank=True, default=None)  # one to many
    persons = models.ManyToManyField(participant, blank=True)  # many to many

    def __str__(self):
        return f'{self.title}-{self.slug}'
